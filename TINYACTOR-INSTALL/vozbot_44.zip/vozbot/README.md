# vozbot

Automatiza un juego de lectura en el navegador: lee la pantalla, saca la emoción
y la frase entre comillas, se la pasa a **tu** app `.py` de generación de voz,
recoge el `.wav` y lo reproduce por un **micrófono virtual** sincronizado con la
cuenta regresiva de la web.

```
vozbot/
├── run.py                 # panel de control o modo consola
├── config.yaml            # todo lo configurable
└── vozbot/
    ├── config.py          # pydantic: config + esquema del guion
    ├── browser.py         # playwright vía CDP: clic por texto, cuenta regresiva
    ├── extractor.py       # emoción + texto "entre comillas" desde el DOM
    ├── ocr.py             # mss + paddleocr (fallback y clics en tu app)
    ├── vlm.py             # modelo de razonamiento: pantalla → JSON (tenacity)
    ├── tts_app.py         # puente con tu generador .py (cli o gui)
    ├── audio.py           # sounddevice + soundfile + pyloudnorm → mic virtual
    ├── recorder.py        # obsws-python (opcional)
    ├── orchestrator.py    # el bucle que juega solo
    └── gui.py             # panel PySide6
```

## 1. Instalar

```bash
python -m venv .venv && .venv\Scripts\activate     # Windows
pip install -r requirements.txt
playwright install chromium
```

## 2. El micrófono emulado

No existe forma de "inyectar" audio en un micrófono desde Python puro: hay que
crear un **cable de audio virtual** y decirle al navegador que ese cable es el
micrófono. vozbot escribe el `.wav` en la salida del cable.

| Sistema | Qué instalar | Dispositivo de salida | Micrófono en Chrome |
|---|---|---|---|
| Windows | [VB-CABLE](https://vb-audio.com/Cable/) | `CABLE Input` | `CABLE Output` |
| macOS | BlackHole 2ch | `BlackHole 2ch` | `BlackHole 2ch` |
| Linux | `pactl load-module module-null-sink sink_name=vozbot` | `vozbot` | `Monitor of vozbot` |

En Chrome: `chrome://settings/content/microphone` → elige el dispositivo del
cable, y da permiso permanente al sitio del juego.

## 3. Abrir Chrome para que el bot lo controle

```bat
chrome.exe --remote-debugging-port=9222 --user-data-dir=C:\chromebot
```

Se usa CDP (no un navegador nuevo) para conservar tu sesión y el permiso de
micrófono ya concedido. Entra al juego y deja la pestaña abierta.

## 4. Conectar tu app generadora de voz

**Modo `cli` (recomendado).** Si tu script acepta argumentos, esto es todo:

```yaml
tts_app:
  modo: cli
  cli:
    script: "C:/mis/generador.py"
    args: ["--texto", "{texto}", "--emocion", "{emocion}"]
  carpeta_salida: "C:/mis/salida"
```

`{texto}` y `{emocion}` se sustituyen en cada ronda. vozbot no lee tu código:
solo espera a que aparezca un `.wav` nuevo y estable en `carpeta_salida`.

Si tu script no acepta argumentos, añádele algo así:

```python
import argparse
p = argparse.ArgumentParser()
p.add_argument("--texto"); p.add_argument("--emocion", default="neutral")
a = p.parse_args()
generar_voz(a.texto, a.emocion)   # tu función de siempre
```

**Modo `gui`.** Si tu app tiene ventana y prefieres no tocarla: pon el título de
la ventana, el texto del botón (`Generar voz`) y las etiquetas de los campos.
vozbot los localiza por OCR, pega el texto con el portapapeles y hace clic.

## 5. Ajustar los botones de la web

En la pestaña **Web** del panel escribes el texto de cada botón, uno por línea.
Se prueban en orden hasta que uno exista: así el mismo perfil sirve aunque la
web cambie de idioma o de etiqueta.

La cuenta regresiva se detecta sola buscando `3 · 2 · 1` y esperando a que
desaparezca. Si el juego la pinta en un contenedor concreto, pon su selector
(`.countdown`) y será más preciso.

## 6. Arrancar

```bash
python run.py            # panel de control
python run.py --consola  # sin ventana, útil para dejarlo corriendo
```

Cada ronda queda registrada en `logs/sesion.tsv` (hora, emoción, wav, frase) y
las capturas que analiza el modelo en `logs/ronda_XXX.png`.

## Orden exacto de una ronda

1. Cierra avisos y lee el DOM.
2. Extrae emoción + frase entre comillas. Si el DOM no da nada, captura la
   pantalla y pregunta al modelo de razonamiento, que responde un JSON validado
   contra `Guion` (con reintentos por `tenacity`).
3. **Genera el audio antes de tocar el micrófono**: así no hay silencio inicial.
4. Clic en «iniciar micrófono».
5. Espera a que termine el `3 · 2 · 1` (+ margen configurable).
6. Reproduce el `.wav` normalizado a −18 LUFS por el cable virtual.
7. Al acabar el audio, clic en «detener» y en «siguiente».

## Si algo no sale

| Síntoma | Causa habitual |
|---|---|
| La web no oye nada | El micrófono del sitio no es la salida del cable, o el `.wav` tiene otro samplerate. Usa **Probar micrófono virtual**. |
| Corta el principio de la frase | Sube `silencio_inicial_ms` y `margen_previo_ms`. |
| Habla antes de tiempo | Pon el `selector` de la cuenta regresiva. |
| No encuentra el botón | Copia el texto exacto del botón, o añade su `aria-label`. |
| Repite la misma frase | Tu app está escribiendo siempre el mismo nombre de archivo: revisa `carpeta_salida`. |
| PaddleOCR tarda al arrancar | Normal la primera vez: descarga modelos. Solo se carga si hace falta. |

## Una nota

Esto reproduce voz sintética hacia un micrófono. Úsalo en tus propias
aplicaciones, en entornos de prueba o donde tengas permiso: en una plataforma
educativa que evalúa la lectura de una persona real, sustituir la voz falsea el
resultado y suele ir contra sus términos de uso.
