#!/usr/bin/env python3
"""Comprueba que todo está listo antes de lanzar las cuentas en paralelo.

    python comprobar.py

Verifica, cuenta por cuenta:
  · que su Chrome responde en su puerto de depuración
  · que su servidor de voz responde y sabe sintetizar
  · que su archivo de micrófono existe y es escribible
"""
from __future__ import annotations

import sys
from pathlib import Path

import httpx
import yaml

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))

from vozbot.config import Config  # noqa: E402

VERDE, ROJO, AMARILLO, FIN = "\033[92m", "\033[91m", "\033[93m", "\033[0m"


def marca(ok: bool | None) -> str:
    if ok is None:
        return f"{AMARILLO}?{FIN}"
    return f"{VERDE}OK{FIN}" if ok else f"{ROJO}FALLA{FIN}"


def prueba_chrome(url: str) -> tuple[bool, str]:
    try:
        r = httpx.get(f"{url}/json/version", timeout=3)
        r.raise_for_status()
        return True, r.json().get("Browser", "Chrome")
    except Exception as e:
        return False, f"{type(e).__name__}"


def prueba_tor(puerto: int) -> tuple[bool | None, str]:
    """¿Hay un Tor escuchando en ese puerto SOCKS?"""
    import socket

    try:
        with socket.create_connection(("127.0.0.1", puerto), timeout=2):
            return True, f"socks {puerto}"
    except Exception:
        return False, f"socks {puerto} cerrado"


def prueba_voz(url: str) -> tuple[bool, str]:
    try:
        r = httpx.get(f"{url.rstrip('/')}/api/estado", timeout=3)
        r.raise_for_status()
        datos = r.json()
        motores = [m for m, ok in (datos.get("motores") or {}).items() if ok]
        return True, f"motores: {', '.join(motores) or 'ninguno'}"
    except Exception as e:
        return False, f"{type(e).__name__}"


def main() -> None:
    cuentas_yaml = BASE / "cuentas.yaml"
    if not cuentas_yaml.is_file():
        print("Falta cuentas.yaml (copia cuentas-ejemplo.yaml)")
        sys.exit(1)

    base = Config.cargar(BASE / "config.yaml")
    cuentas = (yaml.safe_load(cuentas_yaml.read_text(encoding="utf-8")) or {}).get("cuentas", [])
    carpeta_mic = Path(r"C:\vozbot\mic")

    usa_tor = "--tor" in sys.argv
    cabecera = f"\n{'CUENTA':10} {'CHROME':>8}  {'VOZ':>8}  {'MIC':>6}"
    if usa_tor:
        cabecera += f"  {'TOR':>6}"
    print(cabecera + "   detalle")
    print("-" * (86 if usa_tor else 74))

    todo_bien = True
    for i, cuenta in enumerate(cuentas):
        nombre = cuenta["nombre"]
        url_voz = cuenta.get("tts_url") or f"http://127.0.0.1:{8730 + i}"

        ok_chrome, det_chrome = prueba_chrome(cuenta["cdp_url"])
        ok_voz, det_voz = prueba_voz(url_voz)

        archivo = carpeta_mic / f"{nombre}.wav"
        try:
            archivo.parent.mkdir(parents=True, exist_ok=True)
            archivo.touch(exist_ok=True)
            ok_mic = True
        except Exception:
            ok_mic = False

        ok_tor, det_tor = (None, "")
        if usa_tor:
            ok_tor, det_tor = prueba_tor(9050 + i * 2)

        todo_bien &= ok_chrome and ok_voz and ok_mic and (ok_tor is not False)
        detalle = det_voz if ok_voz else f"voz: {det_voz}"
        if not ok_chrome:
            detalle = f"chrome: {det_chrome}"
        if usa_tor and not ok_tor:
            detalle = det_tor

        linea = (
            f"{nombre:10} {marca(ok_chrome):>17}  {marca(ok_voz):>17}  "
            f"{marca(ok_mic):>15}"
        )
        if usa_tor:
            linea += f"  {marca(ok_tor):>15}"
        print(linea + f"   {detalle}")

    print()
    if todo_bien:
        print(f"{VERDE}Todo listo. Lanza:  python paralelo.py{FIN}\n")
    else:
        print(f"{ROJO}Hay cosas pendientes:{FIN}")
        print("  · Chrome en falla  → ejecuta INICIAR-CUENTAS.bat")
        print("  · Voz en falla     → ejecuta INICIAR-VOZ.bat y revisa los puertos")
        print("    (si una instancia tomó otro puerto, ponlo como tts_url en cuentas.yaml)")
        if usa_tor:
            print("  · Tor en falla     → ejecuta INICIAR-TOR.bat y espera al 100%")
        print()


if __name__ == "__main__":
    main()
