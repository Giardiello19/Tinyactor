#!/usr/bin/env python3
"""Juega varias cuentas por turnos, una después de otra.

Cada cuenta necesita su propio Chrome, con su perfil y su puerto de depuración.
El micrófono virtual es uno solo, así que NO pueden jugar a la vez: el audio de
una se colaría en la grabación de la otra. Aquí se turnan.

    python multi.py                    # una vuelta a todas las cuentas
    python multi.py --vueltas 3        # tres vueltas
    python multi.py --solo ana         # solo esa cuenta

La configuración de cada cuenta va en cuentas.yaml.
"""
from __future__ import annotations

import argparse
import logging
import sys
import time
from pathlib import Path

import yaml

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))

from vozbot.config import Config  # noqa: E402
from vozbot.orchestrator import Orquestador  # noqa: E402

log = logging.getLogger("vozbot.multi")


def cargar_cuentas(ruta: Path) -> list[dict]:
    if not ruta.is_file():
        print(f"No encuentro {ruta.name}. Créalo a partir de cuentas-ejemplo.yaml")
        sys.exit(1)
    datos = yaml.safe_load(ruta.read_text(encoding="utf-8")) or {}
    cuentas = datos.get("cuentas") or []
    if not cuentas:
        print("El archivo no tiene ninguna cuenta bajo la clave «cuentas»")
        sys.exit(1)
    return cuentas


def config_para(cuenta: dict, base: Config) -> Config:
    """Copia la configuración base y le cambia lo propio de esta cuenta."""
    cfg = Config.model_validate(base.model_dump())
    cfg.navegador.cdp_url = cuenta["cdp_url"]
    if cuenta.get("url_juego"):
        cfg.navegador.url_juego = cuenta["url_juego"]
    if cuenta.get("max_rondas"):
        cfg.bucle.max_rondas = int(cuenta["max_rondas"])
    # cada cuenta con su propio registro, para no mezclar historiales
    cfg.bucle.carpeta_logs = str(Path(base.bucle.carpeta_logs) / cuenta["nombre"])
    return cfg


def jugar(nombre: str, cfg: Config) -> bool:
    print(f"\n{'=' * 60}\n  CUENTA: {nombre}  ·  {cfg.navegador.cdp_url}\n{'=' * 60}")
    try:
        orq = Orquestador(cfg, on_evento=lambda t, m: print(f"  [{t}] {m}"))
        orq.ejecutar()
        return True
    except Exception as e:
        print(f"  [error] {nombre} falló: {type(e).__name__}: {e}")
        print(f"  [aviso] ¿Está Chrome abierto en {cfg.navegador.cdp_url}?")
        return False


def main() -> None:
    p = argparse.ArgumentParser(description="vozbot multicuenta")
    p.add_argument("--vueltas", type=int, default=1, help="rondas completas a todas las cuentas")
    p.add_argument("--solo", help="jugar solo esta cuenta")
    p.add_argument("--cuentas", default=str(BASE / "cuentas.yaml"))
    p.add_argument("--config", default=str(BASE / "config.yaml"))
    p.add_argument("--pausa", type=float, default=5.0, help="segundos entre cuentas")
    args = p.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s", datefmt="%H:%M:%S")

    base = Config.cargar(args.config)
    cuentas = cargar_cuentas(Path(args.cuentas))
    if args.solo:
        cuentas = [c for c in cuentas if c["nombre"].lower() == args.solo.lower()]
        if not cuentas:
            print(f"No hay ninguna cuenta llamada «{args.solo}»")
            sys.exit(1)

    print(f"Cuentas en la rotación: {', '.join(c['nombre'] for c in cuentas)}")
    print(f"Vueltas: {args.vueltas}\n")

    resumen: dict[str, int] = {}
    for vuelta in range(1, args.vueltas + 1):
        if args.vueltas > 1:
            print(f"\n########  VUELTA {vuelta} de {args.vueltas}  ########")
        for cuenta in cuentas:
            nombre = cuenta["nombre"]
            if jugar(nombre, config_para(cuenta, base)):
                resumen[nombre] = resumen.get(nombre, 0) + 1
            time.sleep(args.pausa)

    print(f"\n{'=' * 60}\n  RESUMEN\n{'=' * 60}")
    for cuenta in cuentas:
        n = cuenta["nombre"]
        print(f"  {n:20} {resumen.get(n, 0)} sesión(es) completada(s)")


if __name__ == "__main__":
    main()
