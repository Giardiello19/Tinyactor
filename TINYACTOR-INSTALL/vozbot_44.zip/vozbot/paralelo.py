#!/usr/bin/env python3
"""Juega varias cuentas A LA VEZ, con el micrófono falso de Chrome.

Cada cuenta tiene su propia ventana de Chrome, su propio archivo de audio y su
propio hilo. Como nadie reproduce sonido por la tarjeta, no hay conflicto: el
navegador lee el wav directamente.

    python paralelo.py                 # todas las cuentas a la vez
    python paralelo.py --solo ana      # una sola
    python paralelo.py --vueltas 2

Requisitos:
  · Chrome abierto con INICIAR-CUENTAS.bat (trae los flags del micrófono falso)
  · Tu app de voz corriendo (python app.py)
  · cuentas.yaml con una entrada por cuenta
"""
from __future__ import annotations

import argparse
import logging
import sys
import threading
import time
from pathlib import Path

import yaml

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))

from vozbot.config import Config  # noqa: E402
from vozbot.orchestrator import Orquestador  # noqa: E402

log = logging.getLogger("vozbot.paralelo")

# Con un servidor de voz por cuenta no hace falta turnarse. El cerrojo solo se
# usa si arrancas con --un-solo-servidor.
CERROJO_TTS = threading.Lock()

# Un solo hilo escribe en consola: sin esto las líneas se entrelazan.
CERROJO_LOG = threading.Lock()


def escribir(cuenta: str, tipo: str, mensaje: str) -> None:
    with CERROJO_LOG:
        print(f"[{cuenta:>8}] [{tipo}] {mensaje}", flush=True)


class OrquestadorParalelo(Orquestador):
    """Igual que el normal. Solo pide turno si se comparte un único servidor."""

    compartir_tts = False

    def _audio_para(self, texto: str, emocion: str):
        if not self.compartir_tts:
            return super()._audio_para(texto, emocion)
        with CERROJO_TTS:
            return super()._audio_para(texto, emocion)


def config_para(cuenta: dict, base: Config, carpeta_mic: Path, indice: int = 0) -> Config:
    cfg = Config.model_validate(base.model_dump())
    nombre = cuenta["nombre"]

    cfg.navegador.cdp_url = cuenta["cdp_url"]

    # --- servidor de voz propio -------------------------------------
    # Si no se indica, se asume que las instancias tomaron 8730, 8731…
    # en el mismo orden en que se lanzaron.
    cfg.tts_app.http.base_url = cuenta.get("tts_url") or f"http://127.0.0.1:{8730 + indice}"

    # Carpeta de salida propia: evita que dos cuentas se pisen los wav.
    salida = cuenta.get("salida") or f"salida_{nombre}"
    cfg.tts_app.http.carpeta_out = salida
    if base.tts_app.carpeta_salida:
        cfg.tts_app.carpeta_salida = str(Path(base.tts_app.carpeta_salida).parent / salida)
    if cuenta.get("url_juego"):
        cfg.navegador.url_juego = cuenta["url_juego"]
    if cuenta.get("max_rondas"):
        cfg.bucle.max_rondas = int(cuenta["max_rondas"])

    # cada cuenta escribe en SU archivo: es lo que evita que se pisen
    cfg.microfono_virtual.modo = "archivo"
    cfg.microfono_virtual.archivo_destino = str(carpeta_mic / f"{nombre}.wav")

    cfg.bucle.carpeta_logs = str(Path(base.bucle.carpeta_logs) / nombre)
    return cfg


def jugar(
    cuenta: dict, base: Config, carpeta_mic: Path, resultados: dict,
    indice: int = 0, compartir: bool = False,
) -> None:
    nombre = cuenta["nombre"]
    cfg = config_para(cuenta, base, carpeta_mic, indice)
    escribir(
        nombre,
        "inicio",
        f"chrome {cfg.navegador.cdp_url.split(':')[-1]} · "
        f"voz {cfg.tts_app.http.base_url.split(':')[-1]} · "
        f"mic {Path(cfg.microfono_virtual.archivo_destino).name}",
    )
    try:
        orq = OrquestadorParalelo(cfg, on_evento=lambda t, m: escribir(nombre, t, m))
        orq.compartir_tts = compartir
        orq.ejecutar()
        resultados[nombre] = "completada"
    except Exception as e:
        escribir(nombre, "error", f"{type(e).__name__}: {e}")
        resultados[nombre] = f"falló: {type(e).__name__}"


def main() -> None:
    p = argparse.ArgumentParser(description="vozbot en paralelo")
    p.add_argument("--cuentas", default=str(BASE / "cuentas.yaml"))
    p.add_argument("--config", default=str(BASE / "config.yaml"))
    p.add_argument("--solo", help="jugar solo esta cuenta")
    p.add_argument("--vueltas", type=int, default=1)
    p.add_argument("--mic", default=r"C:\vozbot\mic", help="carpeta de los wav del micrófono")
    p.add_argument("--retardo", type=float, default=3.0, help="segundos entre arranques")
    p.add_argument(
        "--un-solo-servidor",
        action="store_true",
        help="todas las cuentas comparten una sola app de voz (se turnan)",
    )
    args = p.parse_args()

    logging.basicConfig(level=logging.WARNING)

    base = Config.cargar(args.config)
    datos = yaml.safe_load(Path(args.cuentas).read_text(encoding="utf-8")) or {}
    cuentas = datos.get("cuentas") or []
    if args.solo:
        cuentas = [c for c in cuentas if c["nombre"].lower() == args.solo.lower()]
    if not cuentas:
        print("No hay cuentas que jugar")
        sys.exit(1)

    carpeta_mic = Path(args.mic)
    carpeta_mic.mkdir(parents=True, exist_ok=True)

    print(f"Cuentas en paralelo: {', '.join(c['nombre'] for c in cuentas)}")
    print(f"Archivos de micrófono en: {carpeta_mic}")
    if args.un_solo_servidor:
        print("Modo: un solo servidor de voz (las cuentas se turnan para generar)")
    else:
        print("Modo: un servidor de voz por cuenta (generación simultánea)")
    print()

    for vuelta in range(1, args.vueltas + 1):
        if args.vueltas > 1:
            print(f"\n######## VUELTA {vuelta} de {args.vueltas} ########\n")

        resultados: dict[str, str] = {}
        hilos = []
        for indice, cuenta in enumerate(cuentas):
            h = threading.Thread(
                target=jugar,
                args=(cuenta, base, carpeta_mic, resultados, indice, args.un_solo_servidor),
                name=cuenta["nombre"],
                daemon=False,
            )
            h.start()
            hilos.append(h)
            time.sleep(args.retardo)   # arranques escalonados: menos choques

        for h in hilos:
            h.join()

        print("\n" + "=" * 50)
        for cuenta in cuentas:
            n = cuenta["nombre"]
            print(f"  {n:12} {resultados.get(n, 'sin resultado')}")
        print("=" * 50)


if __name__ == "__main__":
    main()
