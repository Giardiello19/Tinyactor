@echo off
setlocal enabledelayedexpansion
REM ===========================================================
REM  INICIAR-CUENTAS.bat
REM  Abre un Chrome por cuenta con MICROFONO FALSO: cada ventana
REM  lee su propio .wav como si fuera un microfono real.
REM  Asi pueden jugar varias cuentas A LA VEZ.
REM
REM  Edita CUENTAS con los nombres que quieras (uno por cuenta).
REM ===========================================================

set CHROME=C:\Program Files\Google\Chrome\Application\chrome.exe
set PERFILES=C:\chromebot
set MIC=C:\vozbot\mic
set CUENTAS=ana luis mia carlos sofia

REM -----------------------------------------------------------
if not exist "%CHROME%" (
    echo No encuentro Chrome en: %CHROME%
    echo Edita la variable CHROME en este archivo.
    pause
    exit /b 1
)

if not exist "%MIC%" mkdir "%MIC%"

REM Un wav de silencio inicial para que Chrome arranque sin errores
for %%C in (%CUENTAS%) do (
    if not exist "%MIC%\%%C.wav" (
        powershell -NoProfile -Command ^
          "$b=[byte[]]@(82,73,70,70,36,0,0,0,87,65,86,69,102,109,116,32,16,0,0,0,1,0,1,0,128,187,0,0,0,119,1,0,2,0,16,0,100,97,116,97,0,0,0,0); [IO.File]::WriteAllBytes('%MIC%\%%C.wav',$b)"
    )
)

set PUERTO=9222
for %%C in (%CUENTAS%) do (
    echo Abriendo "%%C"  puerto !PUERTO!  mic: %MIC%\%%C.wav
    start "" "%CHROME%" ^
        --remote-debugging-port=!PUERTO! ^
        --user-data-dir="%PERFILES%\%%C" ^
        --use-fake-device-for-media-stream ^
        --use-file-for-fake-audio-capture="%MIC%\%%C.wav%%noloop" ^
        --autoplay-policy=no-user-gesture-required
    set /a PUERTO+=1
    timeout /t 2 /nobreak >nul
)

echo.
echo ===========================================================
echo  En CADA ventana:
echo    1. Inicia sesion con su cuenta
echo    2. Entra al juego
echo    3. El microfono ya es el falso: acepta el permiso y listo
echo       (NO hace falta elegir CABLE Output)
echo.
echo  Cuando esten todas listas:   python paralelo.py
echo ===========================================================
pause
