@echo off
setlocal enabledelayedexpansion
REM ===========================================================
REM  INICIAR-VOZ.bat
REM  Levanta UN servidor de voz por cuenta. Tu app.py elige
REM  puerto libre sola empezando en 8730, asi que quedan:
REM     ana=8730  luis=8731  mia=8732  carlos=8733  sofia=8734
REM
REM  Cada instancia carga su propio modelo Piper en memoria y
REM  atiende solo a su cuenta: nadie espera turno.
REM ===========================================================

set APP_VOZ=C:\Users\darkg\Downloads\vonuevoactor
set CUENTAS=ana luis mia carlos sofia

REM -----------------------------------------------------------
if not exist "%APP_VOZ%\app.py" (
    echo No encuentro app.py en: %APP_VOZ%
    echo Edita la variable APP_VOZ en este archivo.
    pause
    exit /b 1
)

for %%C in (%CUENTAS%) do (
    if not exist "%APP_VOZ%\salida_%%C" mkdir "%APP_VOZ%\salida_%%C"
    echo Arrancando servidor de voz para "%%C"...
    start "voz-%%C" cmd /k "cd /d "%APP_VOZ%" && python app.py"
    REM margen para que tome su puerto antes de lanzar el siguiente
    timeout /t 4 /nobreak >nul
)

echo.
echo ===========================================================
echo  Cinco servidores arrancando. Comprueba en cada ventana el
echo  puerto que imprime: deberian ser 8730, 8731, 8732, 8733, 8734.
echo.
echo  Si alguno tomo otro puerto, corrigelo en cuentas.yaml.
echo  Comprobacion rapida:   python comprobar.py
echo ===========================================================
pause
