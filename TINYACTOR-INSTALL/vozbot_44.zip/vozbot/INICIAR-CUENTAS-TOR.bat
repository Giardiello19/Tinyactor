@echo off
setlocal enabledelayedexpansion
REM ===========================================================
REM  INICIAR-CUENTAS-TOR.bat
REM  Abre un Chrome por cuenta, cada uno saliendo por un circuito
REM  distinto de la red Tor, con microfono falso propio.
REM
REM  ANTES hay que tener corriendo los demonios Tor:
REM  ejecuta INICIAR-TOR.bat y espera a que digan "Bootstrapped 100%".
REM ===========================================================

set CHROME=C:\Program Files\Google\Chrome\Application\chrome.exe
set PERFILES=C:\chromebot
set MIC=C:\vozbot\mic
set CUENTAS=ana luis mia carlos sofia

REM Puerto SOCKS del primer Tor. Los demas van de dos en dos:
REM   ana=9050  luis=9052  mia=9054  carlos=9056  sofia=9058
set SOCKS=9050

REM -----------------------------------------------------------
if not exist "%CHROME%" (
    echo No encuentro Chrome en: %CHROME%
    pause
    exit /b 1
)
if not exist "%MIC%" mkdir "%MIC%"

set PUERTO=9222
for %%C in (%CUENTAS%) do (
    if not exist "%MIC%\%%C.wav" (
        powershell -NoProfile -Command ^
          "$b=[byte[]]@(82,73,70,70,36,0,0,0,87,65,86,69,102,109,116,32,16,0,0,0,1,0,1,0,128,187,0,0,0,119,1,0,2,0,16,0,100,97,116,97,0,0,0,0); [IO.File]::WriteAllBytes('%MIC%\%%C.wav',$b)"
    )

    echo Abriendo "%%C"  cdp=!PUERTO!  tor=socks5://127.0.0.1:!SOCKS!
    start "" "%CHROME%" ^
        --remote-debugging-port=!PUERTO! ^
        --user-data-dir="%PERFILES%\%%C" ^
        --proxy-server="socks5://127.0.0.1:!SOCKS!" ^
        --host-resolver-rules="MAP * ~NOTFOUND , EXCLUDE 127.0.0.1" ^
        --use-fake-device-for-media-stream ^
        --use-file-for-fake-audio-capture="%MIC%\%%C.wav%%noloop" ^
        --autoplay-policy=no-user-gesture-required

    set /a PUERTO+=1
    set /a SOCKS+=2
    timeout /t 3 /nobreak >nul
)

echo.
echo ===========================================================
echo  COMPRUEBA EN CADA VENTANA antes de iniciar sesion:
echo    entra a  https://check.torproject.org
echo    debe decir que SI estas usando Tor, con una IP distinta
echo    en cada ventana.
echo.
echo  Luego inicia sesion y entra al juego en cada una.
echo ===========================================================
pause
