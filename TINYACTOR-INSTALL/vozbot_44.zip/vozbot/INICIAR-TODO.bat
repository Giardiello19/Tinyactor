@echo off
REM ===========================================================
REM  INICIAR-TODO.bat - levanta las tres piezas de una vez:
REM    1. tu app de voz (app.py)
REM    2. Chrome en modo depuracion
REM    3. el panel de vozbot
REM
REM  EDITA LAS DOS RUTAS DE ABAJO la primera vez. Nada mas.
REM ===========================================================

set APP_VOZ=C:\ruta\a\vonuevoactor
set CHROME=C:\Program Files\Google\Chrome\Application\chrome.exe
set PERFIL=C:\chromebot

REM -----------------------------------------------------------
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
    echo No hay entorno virtual. Mira el README para crearlo.
    pause
    exit /b 1
)

if not exist "%APP_VOZ%\app.py" (
    echo No encuentro app.py en: %APP_VOZ%
    echo Edita la variable APP_VOZ en la primera linea de este archivo.
    pause
    exit /b 1
)

echo [1/3] Arrancando tu app de voz...
start "App de voz" cmd /k "cd /d "%APP_VOZ%" && python app.py"

echo       esperando a que cargue el motor...
timeout /t 6 /nobreak >nul

echo [2/3] Abriendo Chrome en modo depuracion...
start "" "%CHROME%" --remote-debugging-port=9222 --user-data-dir="%PERFIL%"
timeout /t 3 /nobreak >nul

echo [3/3] Abriendo el panel de vozbot...
echo.
echo   Antes de pulsar "Empezar a jugar":
echo     - entra al juego en el Chrome que se acaba de abrir
echo     - comprueba que el microfono del sitio sea CABLE Output
echo.
".venv\Scripts\python.exe" run.py
if errorlevel 1 pause
