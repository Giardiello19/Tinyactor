@echo off
setlocal enabledelayedexpansion
REM ===========================================================
REM  INICIAR-TOR.bat
REM  Levanta un demonio Tor por cuenta, cada uno con su circuito
REM  y su puerto SOCKS. Asi las cinco cuentas salen por IPs
REM  distintas y no se relacionan entre si.
REM
REM  Necesitas el "Tor Expert Bundle" (no el navegador):
REM  https://www.torproject.org/download/tor/
REM  Descomprimelo y apunta TOR_EXE al tor.exe que trae.
REM ===========================================================

set TOR_EXE=C:\tor\tor\tor.exe
set TOR_DATOS=C:\tor\datos
set CUENTAS=ana luis mia carlos sofia

REM -----------------------------------------------------------
if not exist "%TOR_EXE%" (
    echo No encuentro tor.exe en: %TOR_EXE%
    echo Descarga el Tor Expert Bundle y edita TOR_EXE en este archivo.
    pause
    exit /b 1
)

set SOCKS=9050
set CONTROL=9051
for %%C in (%CUENTAS%) do (
    if not exist "%TOR_DATOS%\%%C" mkdir "%TOR_DATOS%\%%C"
    echo Arrancando Tor para "%%C"  socks=!SOCKS!
    start "tor-%%C" "%TOR_EXE%" ^
        SocksPort !SOCKS! ^
        ControlPort !CONTROL! ^
        DataDirectory "%TOR_DATOS%\%%C" ^
        Log "notice stdout"
    set /a SOCKS+=2
    set /a CONTROL+=2
    timeout /t 2 /nobreak >nul
)

echo.
echo Espera a que TODAS las ventanas digan "Bootstrapped 100%% (done)".
echo Puede tardar de 30 segundos a 2 minutos la primera vez.
echo Luego ejecuta INICIAR-CUENTAS-TOR.bat
pause
