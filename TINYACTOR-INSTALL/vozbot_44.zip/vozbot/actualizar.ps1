# actualizar.ps1 — copia el código nuevo sobre tu instalación.
# Conserva .venv, config.yaml y la carpeta logs.
#
#   .\actualizar.ps1 -Origen "C:\Users\darkg\Desktop\vozbot"
#
# Origen = la carpeta donde descomprimiste el zip nuevo.

param(
    [Parameter(Mandatory = $true)]
    [string]$Origen,

    [string]$Destino = $PSScriptRoot
)

$ErrorActionPreference = "Stop"

if (-not (Test-Path (Join-Path $Origen "run.py"))) {
    Write-Host "No encuentro run.py en $Origen" -ForegroundColor Red
    Write-Host "Apunta -Origen a la carpeta que contiene run.py, no al zip." -ForegroundColor Yellow
    exit 1
}

# 1. Copia de seguridad de la configuración, por si acaso
$config = Join-Path $Destino "config.yaml"
if (Test-Path $config) {
    $respaldo = Join-Path $Destino ("config-respaldo-" + (Get-Date -Format "yyyyMMdd-HHmmss") + ".yaml")
    Copy-Item $config $respaldo
    Write-Host "Configuración respaldada en $(Split-Path $respaldo -Leaf)" -ForegroundColor DarkGray
}

# 2. Código nuevo: raíz y paquete
Copy-Item (Join-Path $Origen "run.py")         $Destino -Force
Copy-Item (Join-Path $Origen "diagnostico.py") $Destino -Force
Copy-Item (Join-Path $Origen "requirements.txt") $Destino -Force
Copy-Item (Join-Path $Origen "README.md")      $Destino -Force -ErrorAction SilentlyContinue

$paquete = Join-Path $Destino "vozbot"
New-Item -ItemType Directory -Force -Path $paquete | Out-Null
Copy-Item (Join-Path $Origen "vozbot\*.py") $paquete -Force

# 3. Los .bat solo si no existen: puedes haberlos editado con tus rutas
foreach ($bat in @("INICIAR.bat", "INICIAR-TODO.bat")) {
    $ruta = Join-Path $Destino $bat
    if (-not (Test-Path $ruta)) {
        Copy-Item (Join-Path $Origen $bat) $Destino -Force -ErrorAction SilentlyContinue
    } else {
        Write-Host "$bat conservado (ya lo tenías editado)" -ForegroundColor DarkGray
    }
}

Write-Host ""
Write-Host "Código actualizado. Tu .venv y tu config.yaml siguen intactos." -ForegroundColor Green
Write-Host "Arranca con INICIAR.bat" -ForegroundColor Green
