@echo off
cd /d "%~dp0"
title vozbot
py run.py
if errorlevel 1 pause
